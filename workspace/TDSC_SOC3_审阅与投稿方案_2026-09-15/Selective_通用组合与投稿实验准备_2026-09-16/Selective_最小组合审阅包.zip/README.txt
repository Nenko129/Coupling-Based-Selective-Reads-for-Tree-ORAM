This snapshot preserves workspace-relative paths. Python 3.12+ is sufficient for runtime/checks; figures additionally use matplotlib.
See the Chinese 00/03 reports under TDSC_SOC3_审阅与投稿方案_2026-09-15/Selective_通用组合与投稿实验准备_2026-09-16.
Verify SHA256 against MANIFEST.json before running. Existing original-paper PDFs are referenced by hash and are not redistributed.
